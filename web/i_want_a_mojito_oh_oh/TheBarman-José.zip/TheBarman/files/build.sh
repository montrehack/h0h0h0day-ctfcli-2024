#!/bin/bash

rm TheBarman-José.jar
cd TheBarman
rm -r target
./mvnw package
cp target/TheBarman-José.jar ../

