package com.en.voyage.TheBarman;

import com.en.voyage.TheBarman.util.IdUtil;
import com.nimbusds.jose.*;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

public class WonderfulJose {

    static String idFile = "jose_id";
    static String name = "José Barmano";
    static boolean tiredOfPeopleDrinkingTooMuch = true;

    static public List<String> myNameIs() throws IOException, InterruptedException {
        String joseIdInfo = IdUtil.getIdInfo(idFile);
        return Arrays.asList("¡Hola amigo! Me llamo José y soy el mejor bartender de la playa.\n¡Puedo comprobarlo con esta información!", joseIdInfo);
    }

    static public String heresMyId() throws IOException, InterruptedException, JOSEException {
        return IdUtil.getAuthToken(name, tiredOfPeopleDrinkingTooMuch, idFile);
    }

    static public boolean ohYouDontBelieveMeImTheAuthenticJose(String encAuthToken) {
        String token = IdUtil.getAuthTokenToValidate(idFile, encAuthToken);
        return IdUtil.isBarmanAuthorized(name, token);
    }

    static public boolean onlyOrangeJuiceYouHadTooMuch(String encAuthToken) {
        String token = IdUtil.getAuthTokenToValidate(idFile, encAuthToken);
        return IdUtil.isAlcoholTooMuch(token);
    }
}
