package com.en.voyage.TheBarman.util;

import com.nimbusds.jose.*;
import com.nimbusds.jose.crypto.PasswordBasedDecrypter;
import com.nimbusds.jose.crypto.PasswordBasedEncrypter;
import org.springframework.util.StringUtils;

import java.io.*;
import java.text.ParseException;

public class IdUtil {

    enum IdQuery {
        ID,
        ID_INFO
    }

    static String authTokenFormat = "barmanName:%s|authorized:true|youHadTooMuch:%s";

    static public String getAuthToken(String barmanName, boolean noAlcoholForYou, String idFile) throws IOException, InterruptedException, JOSEException {
        String token = String.format(authTokenFormat, barmanName, Boolean.toString(noAlcoholForYou));
        String id = getId(idFile);

        PasswordBasedEncrypter pbEncrypter = new PasswordBasedEncrypter(id, 16, 1919);
        JWEObject authToken = new JWEObject(
                new JWEHeader(JWEAlgorithm.PBES2_HS512_A256KW, EncryptionMethod.A256GCM),
                new Payload(token)
        );

        authToken.encrypt(pbEncrypter);
        return authToken.serialize();
    }

    static public String getAuthTokenToValidate(String idFile, String encAuthToken) {
        try {
            String id = getId(idFile);
            PasswordBasedDecrypter pbDecrypter = new PasswordBasedDecrypter(id);

            JWEObject authToken = JWEObject.parse(encAuthToken);
            authToken.decrypt(pbDecrypter);

            return authToken.getPayload().toString();
        } catch (ParseException | JOSEException | IOException | InterruptedException e) {
            return "";
        }
    }

    static public boolean isBarmanAuthorized(String barmanName, String token) {
        return !token.isEmpty() && StringUtils.countOccurrencesOf(token, "|") == 2 && barmanName.equals(getAuthBarmanName(token)) && isAuthorized(token);
    }

    static private String getAuthBarmanName(String token) {
        String barmanName = getTokenParts(token)[0];
        return barmanName.split(":")[1];
    }

    static private boolean isAuthorized(String token) {
        String authorization = getTokenParts(token)[1];
        return authorization.split(":")[1].equals("true");
    }

    static public boolean isAlcoholTooMuch(String token) {
        if (token.isEmpty() || StringUtils.countOccurrencesOf(token, "|") < 2)
            return true;

        String barmanAlcoholMeter =  getTokenParts(token)[2];
        return barmanAlcoholMeter.split(":")[1].equals("true");
    }

    static private String[] getTokenParts(String token) {
        return token.split("\\|");
    }

    static public String getId(String filename) throws IOException, InterruptedException {
        return getIdInternal(filename, IdQuery.ID);
    }

    static public String getIdInfo(String filename) throws IOException, InterruptedException {
        return getIdInternal(filename, IdQuery.ID_INFO);
    }

    static private String getIdInternal(String filename, IdQuery query) throws IOException, IllegalArgumentException, InterruptedException {
        ProcessBuilder builder;
        byte result[];
        String ids_storage = "/opt/app/IDs/";
        switch (query) {
            case ID:
                FileInputStream inputStream = new FileInputStream( ids_storage + filename);
                result = inputStream.readAllBytes();
                break;
            case ID_INFO:
                builder = new ProcessBuilder("sh", "-c", "ls -al " + filename + "; sha256sum " + filename);
                builder.directory(new File(ids_storage));
                Process process = builder.start();
                InputStream in = process.getInputStream();
                result = in.readAllBytes();

                process.waitFor();
                in.close();
                break;
            default:
                throw new IllegalArgumentException("What was that ?");
        }

        return new String(result, "UTF-8");
    }
}
