package com.en.voyage.TheBarman.Controllers;

import com.en.voyage.TheBarman.WonderfulJose;
import com.en.voyage.TheBarman.util.DrinkUtil;
import com.nimbusds.jose.JOSEException;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.Arrays;

@Controller
@RequestMapping("/")
public class BarController {

    @Autowired
    WonderfulJose wonderfulJose;

    @RequestMapping(method = RequestMethod.GET)
    public String reception(HttpServletRequest request, HttpServletResponse response, Model model) throws IOException, InterruptedException {
        model.addAttribute("jose_message", WonderfulJose.myNameIs());
        return "bar";
    }

    @RequestMapping(value = "/order", method = RequestMethod.GET)
    public String order(HttpServletRequest request, HttpServletResponse response, Model model) throws IOException, InterruptedException, JOSEException, NoSuchAlgorithmException, InvalidKeySpecException {
        String onDutyCookie = wonderfulJose.heresMyId();
        joseBarmanOnDuty(onDutyCookie, response);

        model.addAttribute("jose_message", Arrays.asList("¡Muyyyy biiiennnnn! Es el magnífico daiquiri solo con fresas :)", serveCoctel(onDutyCookie)));
        return "bar";
    }

    @RequestMapping(value = "/goBehindTheBar", method = RequestMethod.GET)
    public String behindTheBar(HttpServletRequest request, HttpServletResponse response, Model model,
                               @CookieValue(value = "OnDuty", required = false) String onDutyCookie) throws IOException, InterruptedException, JOSEException {
        if (onDutyCookie == null || onDutyCookie.isEmpty())
            return "redirect:/";

        model.addAttribute("jose_message", Arrays.asList("Bon ! Qu'est-ce que ça peut bien goûter ce petit chef-d'oeuvre ?", serveCoctel(onDutyCookie)));
        return "bar";
    }

    private String serveCoctel(String onDutyCookie) {
        if (unlockTastyAlcohol(onDutyCookie))
            return DrinkUtil.completeDrink("a_nice_coctel_with_a_little_flag_and_a_beach_umbrella");
        return DrinkUtil.completeDrink("juice");
    }

    private boolean unlockTastyAlcohol(String onDutyCookie) {
        return WonderfulJose.ohYouDontBelieveMeImTheAuthenticJose(onDutyCookie) && !WonderfulJose.onlyOrangeJuiceYouHadTooMuch(onDutyCookie);
    }

    private void joseBarmanOnDuty(String joseToken, HttpServletResponse response) {
        Cookie onDutyCookie = new Cookie("OnDuty", joseToken);
        onDutyCookie.setHttpOnly(true);
        onDutyCookie.setSecure(false);
        onDutyCookie.setPath("/");
        onDutyCookie.setMaxAge(3600);
        response.addCookie(onDutyCookie);
    }
}

