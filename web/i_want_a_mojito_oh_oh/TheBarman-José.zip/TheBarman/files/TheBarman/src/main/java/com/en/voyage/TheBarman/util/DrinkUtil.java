package com.en.voyage.TheBarman.util;

import java.io.*;

public class DrinkUtil {
    static public String completeDrink(String drinkName) {
        try {
            FileInputStream inputStream = new FileInputStream("/opt/app/drinks/" + drinkName);
            byte result[] = inputStream.readAllBytes();
            return new String(result, "UTF-8");
        } catch (IOException e) {
            return "No drink today...";
        }
    }
}
