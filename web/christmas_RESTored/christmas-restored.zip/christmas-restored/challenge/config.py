import secrets

secret_key = secrets.token_bytes(32).hex()
